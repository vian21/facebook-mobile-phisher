# facebook-mobile-phisher

A HTML &amp; PHP phishing app for mobile devices 

It saves the credentials in pass.txt using PHP and redirects the user to the real facebook site. No databse needed!

![1](https://github.com/vian21/facebook-mobile-phisher/blob/dc95d2b51ee97ac374f79de31e252eadb074be2a/screenshots/1.png)
