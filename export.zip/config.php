<?php
    $title="Play Video";
    $icon="lite.png";
    ?>